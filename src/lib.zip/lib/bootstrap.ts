/**
 * Bootstrap - OnSite Timekeeper v2
 * 
 * SINGLETON listener initialization.
 * This is the ONLY place that registers callbacks.
 */

import { AppState, type AppStateStatus } from 'react-native';
import { logger } from './logger';
import { useWorkSessionStore } from '../stores/workSessionStore';
import { useRecordStore } from '../stores/recordStore';
import {
  startHeartbeat,
  stopHeartbeat,
  setGeofenceCallback,
  setReconcileCallback,
  clearCallbacks,
  updateHeartbeatInterval,
  setBackgroundUserId,
  clearBackgroundUserId,
} from './backgroundTasks';

// ============================================
// SINGLETON STATE
// ============================================

let listenersInitialized = false;
let appStateSubscription: ReturnType<typeof AppState.addEventListener> | null = null;

// ============================================
// APP STATE HANDLER
// ============================================

async function handleAppStateChange(nextState: AppStateStatus): Promise<void> {
  logger.debug('boot', `📱 AppState: ${nextState}`);
  
  if (nextState === 'active') {
    // Update heartbeat interval when app becomes active
    await updateHeartbeatInterval();
  }
}

// ============================================
// GEOFENCE CALLBACK
// ============================================

function handleGeofenceEvent(event: { type: 'enter' | 'exit'; regionIdentifier: string; timestamp: number }): void {
  const workSession = useWorkSessionStore.getState();
  const recordStore = useRecordStore.getState();
  
  // Find location name from store
  const state = recordStore as any;
  const locations = state.locations || state.savedLocations || [];
  const location = locations.find((l: any) => l.id === event.regionIdentifier);
  const locationName = location?.name || null; // null = not found yet
  
  logger.info('geofence', `🎯 Geofence event: ${event.type} @ ${event.regionIdentifier}`);
  
  // Queue event in workSessionStore (handles ready gate)
  if (event.type === 'enter') {
    workSession.handleGeofenceEnter(event.regionIdentifier, locationName);
  } else {
    workSession.handleGeofenceExit(event.regionIdentifier, locationName);
  }
}

// ============================================
// RECONCILE CALLBACK
// ============================================

async function handleReconcile(): Promise<void> {
  logger.info('geofence', '🔄 Reconcile triggered');
  // Reconcile logic is in workSessionStore
}

// ============================================
// INITIALIZE LISTENERS (CALL ONCE!)
// ============================================

export async function initializeListeners(): Promise<void> {
  if (listenersInitialized) {
    logger.debug('boot', '⚠️ Listeners already initialized - skipping');
    return;
  }
  
  logger.info('boot', '🎧 Initializing singleton listeners...');
  
  try {
    // Register callbacks (ONCE!)
    setGeofenceCallback(handleGeofenceEvent);
    setReconcileCallback(handleReconcile);
    
    // AppState listener (ONCE!)
    if (appStateSubscription) {
      appStateSubscription.remove();
    }
    appStateSubscription = AppState.addEventListener('change', handleAppStateChange);
    
    // Start heartbeat
    await startHeartbeat();
    
    listenersInitialized = true;
    logger.info('boot', '✅ Singleton listeners ready');
    
  } catch (error) {
    logger.error('boot', 'Failed to initialize listeners', { error: String(error) });
    // Mark as initialized to prevent infinite retries
    listenersInitialized = true;
  }
}

// ============================================
// CLEANUP LISTENERS
// ============================================

export async function cleanupListeners(): Promise<void> {
  logger.info('boot', '🧹 Cleaning up listeners...');
  
  if (appStateSubscription) {
    appStateSubscription.remove();
    appStateSubscription = null;
  }
  
  clearCallbacks();
  await stopHeartbeat();
  
  listenersInitialized = false;
  logger.info('boot', '✅ Listeners cleanup complete');
}

// ============================================
// USER SESSION HANDLERS
// ============================================

export async function onUserLogin(userId: string): Promise<void> {
  logger.info('boot', `👤 User logged in: ${userId.substring(0, 8)}...`);
  await setBackgroundUserId(userId);
  await updateHeartbeatInterval();
}

export async function onUserLogout(): Promise<void> {
  logger.info('boot', '👤 User logging out...');
  await clearBackgroundUserId();
  
  const workSession = useWorkSessionStore.getState();
  if (workSession.clearPending) {
    await workSession.clearPending();
  }
  if (workSession.clearPause) {
    workSession.clearPause();
  }
}

// ============================================
// STATUS
// ============================================

export function areListenersInitialized(): boolean {
  return listenersInitialized;
}

/**
 * Force re-initialization (use with caution)
 */
export async function forceReinitialize(): Promise<void> {
  await cleanupListeners();
  await initializeListeners();
}
