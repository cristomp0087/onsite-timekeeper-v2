/**
 * Permission Status Hook - OnSite Timekeeper
 * 
 * Monitors:
 * - Location permissions (foreground + background)
 * - Notification permissions
 * 
 * Shows banners when permissions are missing.
 */

import { useState, useEffect, useCallback } from 'react';
import { AppState, AppStateStatus, Platform, Linking } from 'react-native';
import * as Location from 'expo-location';
import * as Notifications from 'expo-notifications';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { logger } from '../lib/logger';
import { captureError } from '../lib/database/errors';

// ============================================
// TYPES
// ============================================

export interface PermissionStatus {
  // Permissions
  locationForeground: boolean;
  locationBackground: boolean;
  notificationsEnabled: boolean;
  
  // Computed
  canTrackReliably: boolean;
  needsAttention: boolean;
  
  // State
  isChecking: boolean;
  
  // Actions
  checkPermissions: () => Promise<void>;
  openAppSettings: () => void;
  openNotificationSettings: () => void;
  requestLocationPermission: () => Promise<boolean>;
  requestNotificationPermission: () => Promise<boolean>;
}

// ============================================
// CONSTANTS
// ============================================

const NOTIFICATION_DISABLED_LOG_KEY = '@onsite:notificationDisabledLogDate';
const PERMISSION_CHECK_INTERVAL = 120000; // 2 minutes

// ============================================
// HOOK
// ============================================

export function usePermissionStatus(): PermissionStatus {
  const [locationForeground, setLocationForeground] = useState(true);
  const [locationBackground, setLocationBackground] = useState(true);
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);
  const [isChecking, setIsChecking] = useState(false);

  // ============================================
  // CHECK PERMISSIONS
  // ============================================
  
  const checkPermissions = useCallback(async () => {
    setIsChecking(true);
    
    try {
      // Check location permissions
      const { status: fgStatus } = await Location.getForegroundPermissionsAsync();
      const { status: bgStatus } = await Location.getBackgroundPermissionsAsync();
      
      const hasForeground = fgStatus === 'granted';
      const hasBackground = bgStatus === 'granted';
      
      setLocationForeground(hasForeground);
      setLocationBackground(hasBackground);
      
      // Check notification permission
      const { status: notifStatus } = await Notifications.getPermissionsAsync();
      const hasNotifications = notifStatus === 'granted';
      setNotificationsEnabled(hasNotifications);
      
      logger.debug('permissions', 'Permission check completed', {
        locationForeground: hasForeground,
        locationBackground: hasBackground,
        notificationsEnabled: hasNotifications,
      });
      
      // Log to Supabase if notifications disabled (once per day)
      if (!hasNotifications) {
        await logNotificationDisabledOnce();
      }
      
    } catch (error) {
      logger.error('permissions', 'Error checking permissions', { error: String(error) });
    } finally {
      setIsChecking(false);
    }
  }, []);

  // ============================================
  // LOG NOTIFICATION DISABLED (ONCE PER DAY)
  // ============================================
  
  async function logNotificationDisabledOnce(): Promise<void> {
    try {
      const today = new Date().toISOString().split('T')[0];
      const lastLogDate = await AsyncStorage.getItem(NOTIFICATION_DISABLED_LOG_KEY);
      
      if (lastLogDate === today) {
        return; // Already logged today
      }
      
      // Log to Supabase
      await captureError(
        new Error('User has notifications disabled'),
        'notification_error',
        {
          platform: Platform.OS,
          action: 'permission_check',
        }
      );
      
      await AsyncStorage.setItem(NOTIFICATION_DISABLED_LOG_KEY, today);
      logger.info('permissions', '📝 Logged notification disabled to Supabase');
      
    } catch (error) {
      // Ignore errors - this is non-critical
      logger.debug('permissions', 'Error logging notification disabled', { error: String(error) });
    }
  }

  // ============================================
  // ACTIONS
  // ============================================
  
  const openAppSettings = useCallback(() => {
    if (Platform.OS === 'ios') {
      Linking.openURL('app-settings:');
    } else {
      Linking.openSettings();
    }
  }, []);

  const openNotificationSettings = useCallback(() => {
    if (Platform.OS === 'android') {
      Linking.openSettings();
    } else {
      Linking.openURL('app-settings:');
    }
  }, []);

  const requestLocationPermission = useCallback(async (): Promise<boolean> => {
    try {
      const { status: fgStatus } = await Location.requestForegroundPermissionsAsync();
      if (fgStatus !== 'granted') {
        return false;
      }
      
      const { status: bgStatus } = await Location.requestBackgroundPermissionsAsync();
      
      setLocationForeground(fgStatus === 'granted');
      setLocationBackground(bgStatus === 'granted');
      
      return bgStatus === 'granted';
    } catch (error) {
      logger.error('permissions', 'Error requesting location permission', { error: String(error) });
      return false;
    }
  }, []);

  const requestNotificationPermission = useCallback(async (): Promise<boolean> => {
    try {
      const { status } = await Notifications.requestPermissionsAsync();
      const granted = status === 'granted';
      setNotificationsEnabled(granted);
      return granted;
    } catch (error) {
      logger.error('permissions', 'Error requesting notification permission', { error: String(error) });
      return false;
    }
  }, []);

  // ============================================
  // EFFECTS
  // ============================================
  
  // Check on mount
  useEffect(() => {
    checkPermissions();
  }, [checkPermissions]);

  // Check when app returns to foreground
  useEffect(() => {
    const handleAppStateChange = (nextState: AppStateStatus) => {
      if (nextState === 'active') {
        checkPermissions();
      }
    };

    const subscription = AppState.addEventListener('change', handleAppStateChange);
    return () => subscription.remove();
  }, [checkPermissions]);

  // Periodic check every 2 minutes
  useEffect(() => {
    const interval = setInterval(() => {
      checkPermissions();
    }, PERMISSION_CHECK_INTERVAL);
    
    return () => clearInterval(interval);
  }, [checkPermissions]);

  // ============================================
  // COMPUTED VALUES
  // ============================================
  
  const canTrackReliably = 
    locationForeground && 
    locationBackground && 
    notificationsEnabled;
  
  const needsAttention = 
    !locationForeground || 
    !locationBackground || 
    !notificationsEnabled;

  return {
    // Permissions
    locationForeground,
    locationBackground,
    notificationsEnabled,
    
    // Computed
    canTrackReliably,
    needsAttention,
    
    // State
    isChecking,
    
    // Actions
    checkPermissions,
    openAppSettings,
    openNotificationSettings,
    requestLocationPermission,
    requestNotificationPermission,
  };
}
